Ce dossier contient notre projet.

runnable/ contient le test de shakespear avec un scripte pour pouvoir 
l'executer. Vous devez vous placer dans runnable/ pour ne pas avoir de problème
de chemin vers les données de test.

Notre code est aussi disponnible sur github à l'adresse suivante : 
https://github.com/KyrLu/ALGAV_Tries
