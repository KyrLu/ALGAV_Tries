# !/bin/bash

java -jar shakespeareTest.jar shakespeare
