# !/bin/bash

java -jar exempleDeBase.jar
